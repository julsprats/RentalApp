package com.example.mapboxdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import com.example.mapboxdemo.databinding.ActivityMainBinding
import com.mapbox.geojson.Point
import com.mapbox.maps.Style
import com.mapbox.maps.extension.style.layers.addLayer
import com.mapbox.maps.extension.style.layers.generated.lineLayer
import com.mapbox.maps.extension.style.sources.addSource
import com.mapbox.maps.extension.style.sources.generated.geoJsonSource
import com.mapbox.maps.plugin.annotation.AnnotationConfig
import com.mapbox.maps.plugin.annotation.AnnotationSourceOptions
import com.mapbox.maps.plugin.annotation.annotations
import com.mapbox.maps.plugin.annotation.generated.PointAnnotationOptions
import com.mapbox.maps.plugin.annotation.generated.createPointAnnotationManager

class MainActivity : AppCompatActivity() {

    private val TAG = "MY_APP"

    lateinit var binding:ActivityMainBinding

    private val MY_COORDINATES = mutableListOf<Point>(
        Point.fromLngLat(-74.0060, 40.7128),        // new york city
        Point.fromLngLat(-73.5674,45.5019),         // montreal
        Point.fromLngLat(-72.5778, 44.5588),
        Point.fromLngLat(-75.6972,45.4215)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.btnShowMarker.setOnClickListener {
            addAnnotationToMap(43.6532, -79.3832)
        }


        binding.btnShowManyMarkers.setOnClickListener {
            addManyAnnotations(MY_COORDINATES, R.drawable.camping)
        }

    }

    // helper functions to show annotations

    private fun addManyAnnotations(coordinatesList:MutableList<Point>, @DrawableRes drawableImageResourceId: Int = R.drawable.red_marker) {

        val icon = MapboxUtils.bitmapFromDrawableRes(applicationContext, drawableImageResourceId)

        if (icon == null) {
            Log.d(TAG, "ERROR: Unable to convert provided image into the correct format.")
            return
        }

        val annotationApi = binding.mapView?.annotations
        val pointAnnotationManager =
            annotationApi?.createPointAnnotationManager(
                AnnotationConfig(
                    annotationSourceOptions = AnnotationSourceOptions(maxZoom = 16)
                )
            )

        // loop through our list of coordinates & add them to the map
        val pointAnnotationOptionsList: MutableList<PointAnnotationOptions> = ArrayList()

        for (currCoordinate in coordinatesList) {
            pointAnnotationOptionsList.add(
                PointAnnotationOptions()
                    .withPoint(currCoordinate)
                    .withIconImage(icon)
            )
        }

        pointAnnotationManager?.create(pointAnnotationOptionsList)

    }

    private fun addAnnotationToMap(lat:Double, lng:Double, @DrawableRes drawableImageResourceId: Int = R.drawable.red_marker) {
        Log.d(TAG, "Attempting to add annotation to map")

        // get the image you want to use as a map marker
        // & resize it to fit the proportion of the map as the user zooms in and zoom out
        // val icon = MapboxUtils.bitmapFromDrawableRes(applicationContext, R.drawable.pikachu)
        val icon = MapboxUtils.bitmapFromDrawableRes(applicationContext, drawableImageResourceId)

        // error handling code: sometimes, the person may provide an image that cannot be
        // properly converted to a map marker
        if (icon == null) {
            Log.d(TAG, "ERROR: Unable to convert provided image into the correct format.")
            return
        }


        // code sets up the map so you can add markers
        val annotationApi = binding.mapView?.annotations
        val pointAnnotationManager =
            annotationApi?.createPointAnnotationManager(
                AnnotationConfig(
                    annotationSourceOptions = AnnotationSourceOptions(maxZoom = 16)
                )
            )

        // Create a marker & configure the options for that marker
        val pointAnnotationOptions: PointAnnotationOptions = PointAnnotationOptions()
            .withPoint(Point.fromLngLat(lng, lat))
            .withIconImage(icon)

        // Add the resulting pointAnnotation to the map.
        pointAnnotationManager?.create(pointAnnotationOptions)


    }



}